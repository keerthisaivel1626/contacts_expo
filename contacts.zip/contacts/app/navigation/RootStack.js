import React from 'react';
import { createStackNavigator } from '@react-navigation/stack';

import HomeStack from './HomeStack';


const Stack = createStackNavigator();

const RootStack = () => {
  
  return (
    <Stack.Navigator
      initialRouteName={"HomeStack"}
     
      headerMode='none'
      mode='modal'
    >
   
     
      <Stack.Screen
        name="HomeStack"
        component={HomeStack}
      />
    
    </Stack.Navigator>
  );
}

export default RootStack;