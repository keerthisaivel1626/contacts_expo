
import React from 'react';
import { createStackNavigator } from '@react-navigation/stack';
import   Home from '../screens/Home';
import AddContacts from '../components/AddContacts'



const Stack = createStackNavigator();

const HomeStack = () => {
  return (
    <Stack.Navigator
      initialRouteName="Home"
     
    >
      <Stack.Screen
        name="Home"
        component={Home}
        options={{ title:'' }}
      />
       <Stack.Screen
        name="AddContacts"
        component={AddContacts}
        options={{ title: '' }}
      />
      
     
    </Stack.Navigator>
  );
}

export default HomeStack;
