import { action } from "../store/typeSafe";

export const addContactAction = (payload)  => action('ADD_CONTACT', payload);
export const storeContactAction = (payload) => action('STORE_CONTACT', payload);
