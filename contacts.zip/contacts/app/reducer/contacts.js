import { createReducer } from "../store/typeSafe";
import {storeContactAction} from "../actions/contactsAction";

const initialState = {
  contacts: [
    {
      "name":"keerthana",
      "number":"9977882233"
    }
  ]
};

export const contactsReducer = createReducer(initialState)
.handleAction(
    storeContactAction,
    (state, action) => {
      console.log(action);
      let oldContacts = state.contacts;
      oldContacts.push(action.payload)
      state.contacts = oldContacts;
    })
