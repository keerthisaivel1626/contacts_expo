
import { delay, put, takeLatest } from 'redux-saga/effects';
import { getActionType } from '../store/typeSafe';
import {storeContactAction, addContactAction} from "../actions/contactsAction";

export function *addContactSaga(action) {
      yield put(storeContactAction(action.payload));
}

export const contactSagas = [takeLatest(getActionType(addContactAction), addContactSaga)];

