
import { combineReducers } from 'redux';
import { contactsReducer } from '../reducer/contacts';

export const rootReducers: any = combineReducers({
  contacts: contactsReducer
});
