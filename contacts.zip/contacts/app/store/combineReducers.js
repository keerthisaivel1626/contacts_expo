
import { combineReducers } from 'redux';
import { contactsReducer } from '../reducer/contacts';

export const rootReducers = combineReducers({
  contacts: contactsReducer
});
