// @flow Copyright ©2021 G2TechSoft. All Rights Reserved.
import { applyMiddleware, createStore } from 'redux';
import { persistReducer, persistStore } from 'redux-persist';
import { createLogger } from 'redux-logger';
import AsyncStorage from '@react-native-async-storage/async-storage';
import createSagaMiddleware from 'redux-saga';

import { rootReducers } from './combineReducers'; // where reducers is a object of reducers
import { rootSagas } from './combineSagas';
import autoMergeLevel2 from 'redux-persist/lib/stateReconciler/autoMergeLevel2';

const persistConfig = {
  key: 'root',
  whitelist: ['login'], // Only these reducers will be persisted.
  storage: AsyncStorage,
  stateReconciler: autoMergeLevel2,
  debug: true, // to get useful logging
};

const persistedReducer = persistReducer(persistConfig, rootReducers);
const initState = {};
const middleware = [];
const sagaMiddleware = createSagaMiddleware();
middleware.push(sagaMiddleware);

export const store: any = createStore(
  persistedReducer,
  initState,
  applyMiddleware(...middleware),
);
const persistor = persistStore(store);
sagaMiddleware.run(rootSagas);

store.subscribe(() => {
  console.log('Store Changed ', store.getState());
});

const configureStore = () => {
  return { persistor, store };
};

export default configureStore;

global.store = store;
