
import { applyMiddleware, createStore } from 'redux';
import { persistReducer, persistStore } from 'redux-persist';
import { createLogger } from 'redux-logger';
import AsyncStorage from '@react-native-async-storage/async-storage';
import createSagaMiddleware from 'redux-saga';
import { rootReducers } from './combineReducers'; 
import { rootSagas } from './combineSagas';
import autoMergeLevel2 from 'redux-persist/lib/stateReconciler/autoMergeLevel2';
import autoMergeLevel1 from 'redux-persist/lib/stateReconciler/autoMergeLevel1';

const sagaMiddleware = createSagaMiddleware();
const middleware = [];
middleware.push(sagaMiddleware);

const persistConfig = {
  key: 'root',
  storage: AsyncStorage,
  whitelist: ['contatcs'],
 // stateReconciler: autoMergeLevel1,
 stateReconciler: autoMergeLevel2,
 debug:true

};
const persistedReducer = persistReducer(persistConfig, rootReducers);
const initState = {};
export const store = createStore(
  persistedReducer,
  initState,
  applyMiddleware(...middleware),
);

const persistor = persistStore(store);
sagaMiddleware.run(rootSagas);

store.subscribe(() => {
  console.log('Store Changed ', store.getState());
});

const configureStore = () => {
  return { persistor, store };
};

export default configureStore;

//global.store = store;
