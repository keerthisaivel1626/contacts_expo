import { all } from 'redux-saga/effects';
import { contactSagas } from "../sagas/contactSagas";

export function *rootSagas() {
  yield all([
    ...contactSagas
  ]);
}