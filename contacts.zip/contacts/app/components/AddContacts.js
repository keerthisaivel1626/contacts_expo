import React, {useEffect, useState} from 'react';
import Ionicons from 'react-native-vector-icons/Ionicons';

import { useDispatch, useSelector } from 'react-redux';
import { addContactAction } from "../actions/contactsAction"
import {
  SafeAreaView,
  ScrollView,
  StatusBar,
  StyleSheet,
  Text,
  TouchableOpacity,
  Alert,
  TextInput,
  View,
  FlatList,
  Platform,
  Button,
} from 'react-native';
import arrow from '../assert/right-arrow.png'
import { NavigationContainer } from '@react-navigation/native';
import { createStackNavigator } from '@react-navigation/stack';
import {Feather,AntDesign} from 'react-native-vector-icons';
import { BottomSheet } from 'react-native-btr';
import {
  COLOR,
  width,
  headerHeight,
  cardBorderRadius,
  getPercentageHeight,
  getPercentageWidth,
} from '../constants/index';

const AddContacts = ({ navigation}) => {
 const [name, setName] = useState('');
const [number, setNumber] = useState('');
const dispatch = useDispatch();
const StoreContacts =()=>{
  if (!name) {
    Alert.alert('Please fill name');
    return;
  }
  if (!number) {
    Alert.alert('Please fill number');
    return;    
  }
   console.log(name, number); 
   if(name.length>=2&&number.length>=6){
  const data = {
           name:name,
           number:number
          };
    dispatch(addContactAction(data));
    navigation.navigate('Home')
   }else{
      Alert.alert('invalid name and number');

   }
}

  return (
    
    <View style={{backgroundColor:'#F2F3F3',flex:1}}>
      <View style={styles.contactHeader}>
       
        <Text style={styles.contactTitle}> Add Contacts</Text>
      </View>       
        <View style={styles.box}>
        <Text style={styles.contactListHead}> Contact Info </Text>
        <ScrollView>
        <TextInput
              style={styles.inputBox}
              placeholder="Full Name"
              onChangeText={setName}
              value={name}
            />
             <TextInput
              style={styles.inputBox}
              keyboardType='numeric'
              placeholder="Contact Number"
              onChangeText={setNumber}
              value={number}
            />
            </ScrollView>
             <TouchableOpacity style={styles.appButtonContainer} onPress={() =>{StoreContacts() }}>
          
                <Text  style={styles.appButtonText}>SUBMIT</Text>
                 </TouchableOpacity>           
            </View> 
    </View>
  );
};

const styles = StyleSheet.create({
  appButtonContainer: {
    backgroundColor: '#525298',
    borderRadius: 30,
    paddingVertical: 10,
    
    height: 50,
    width: '100%',
   
    alignSelf: 'center',
    marginTop:30
    
  },
   contactListHead: {
    fontFamily: 'Cochin',
    fontSize: 20,
    fontWeight: 'bold',
    paddingTop: 10,
    //marginLeft:10,
  },
   box: {
    backgroundColor: 'white',
    borderRadius: cardBorderRadius,
    width: '100%',
    paddingTop:20,
    paddingBottom: 30,
    paddingHorizontal:20,
    height:400,
    justifyContent: 'flex-end',
 
     //bottom:80
    marginTop:200
    
   // marginLeft:20
    
  },
  appButtonText: {
    fontSize: 18,
    color: "#fff",
    textAlign:'center',
    alignSelf: "center",

  },
  contactHeader: {
    flexDirection: 'row',
    justifyContent: 'center',
    backgroundColor: 'white',
  },
  inputBox: {
    borderRadius:12,
    height: 60,
    width: '100%',
    backgroundColor:'white',
    marginTop:30,
    alignItems:'center',
    paddingLeft: 8,
    paddingRight: 8,
    borderWidth:2,
    borderColor:'#F2F3F3'
         
  },
  contactTitle: {
    fontFamily: 'Cochin',
    fontSize: 20,
    fontWeight: 'bold',
    textAlign: 'center',
    paddingTop: 30,
  },

});

export default AddContacts;
