import React, {useEffect, useState} from 'react';
import Ionicons from 'react-native-vector-icons/Ionicons';
import SwipeButton from 'rn-swipe-button';
import {
  SafeAreaView,
  ScrollView,
  StatusBar,
  StyleSheet,
  Text,
  TouchableOpacity,
  Alert,
  TextInput,
  View,
  FlatList,
  Platform,
  Button,
} from 'react-native';
import arrow from '../assert/right-arrow.png'
import { NavigationContainer } from '@react-navigation/native';
import { createStackNavigator } from '@react-navigation/stack';
import {Feather,AntDesign} from 'react-native-vector-icons';

import { useDispatch, useSelector } from 'react-redux';
import {
  COLOR,
  width,
  headerHeight,
  cardBorderRadius,
  getPercentageHeight,
  getPercentageWidth,
} from '../constants/index';

const Home = ({ navigation }) => {
  const [inputTag, setInputTag] = useState('');
  const myDetails = useSelector((state) => state.localstore);
  const [filteredContacts, setFilteredContacts] = useState([]);
  const myContacts = useSelector((state) => {
    return state.contacts.contacts;
  });

  useEffect(() => {
    setFilteredContacts(myContacts);
  }, [myContacts]);


  useEffect(() => {
    console.log(inputTag)
    let filter_array = myContacts
      if (inputTag.length > 0) {
        filter_array = myContacts.filter(function(value) {
          console.log(value)
        return value.name.includes(inputTag) || value.number.includes(inputTag); 
      });
      }
      setFilteredContacts(filter_array);
    }, [inputTag, myContacts]);

  const ItemView = ({item}) => {
    return (
      <View style={styles.itemStyle}>
        <View style={styles.circle}>
        <Text style={{textAlign:'center',fontWeight:'bold',fontSize:'20'}}> {item.name[0].toUpperCase()}</Text>
        </View>
        <View>
        <Text style={{justifyContent:'space-between',fontWeight:'bold',marginLeft:20,marginTop:2}}>        
          {item.name}         
        </Text> 
         <Text style={{justifyContent:'space-between',marginLeft:20,marginTop:10}}>         
          {item.number}         
        </Text>
        </View>
      </View>
    );
  };

  const ItemSeparatorView = () => {
    return (
      <View
        style={{
          height: 15,
          width: '100%',
          backgroundColor: 'white',
          justifyContent:'space-between',
          flexDirection: 'row',
          marginTop:20, 
        }}
      />
    );
  };

  return (
    < View style={{backgroundColor:'white', flex:1}}>
      <View style={styles.contactHeader}> 
        <Text style={styles.contactTitle}>Contacts</Text>
      </View>
      <View style={styles.container}>
        <View style={styles.searchBox}>
          <TextInput
            style={styles.inputBox}
            placeholder="Search"
            onChangeText={setInputTag}
            value={inputTag}
          />
          <Feather
            name={'search'}
            size={30}
            color={'black'}
          />
        </View>
        <Text style={styles.contactListHead}> All Contacts</Text>
        <FlatList
          data={filteredContacts}
          keyExtractor={(item, index) => index.toString()}
          ItemSeparatorComponent={ItemSeparatorView}
          renderItem={ItemView}
          style={styles.contactList}
        />  
        <TouchableOpacity style={styles.appButtonContainer} onPress={() => navigation.navigate('AddContacts')}>
         <View style={{backgroundColor:'white', height:50,width:50,borderRadius:25,justifyContent:'center',alignSelf:'center'}}>
           <AntDesign  
             style={{ alignItems:'center',justifyContent:'center',alignSelf:'center',}}
             name={'arrowright'}
             size={30}
             color={'#525298'}
           />
         </View>
         <Text  style={styles.appButtonText}>Add Contacts</Text>
       </TouchableOpacity> 
      </View>    
    </View>
  );
};

const styles = StyleSheet.create({
  appButtonContainer: {
    elevation: 8,
    backgroundColor: '#525298',
    borderRadius: 30,
    paddingVertical: 10,
    paddingHorizontal: 12,
    flexDirection:'row',
    bottom:50,
    width:'80%',
    alignSelf: 'center',    
  },
  appButtonText: {
    fontSize: 18,
    color: "#fff",
    textAlign:'center',
    alignSelf: "center",
    paddingLeft:50

  },
  contactHeader: {
    flexDirection: 'row',
    justifyContent: 'center',
    backgroundColor: 'white',
  },
  itemStyle: {
    flexDirection: 'row',  
  },
  circle: {
    width: 40,
    height: 40,
    borderRadius: 40 / 2,
    backgroundColor: 'red',
    justifyContent:'center',
    textAlign:'center',
    alignItems:'center',
    alignContent:'center'
    
  },
  container: {
    flex: 1,
    justifyContent: 'center',
  },

  searchBox: {
    backgroundColor: 'white',
    marginTop: 30,
    width: '90%',
    borderColor: '#ECEEEF',
    borderWidth: 1,
    alignSelf: 'center',
    borderRadius: 12,
    paddingLeft: 8,
    paddingRight: 8,
    flexDirection: 'row',
    paddingVertical:
    Platform.OS === 'ios' ?10 :5,
    paddingHorizontal:10,
    alignItems: 'center',
  },
 
  contactList: {
    justifyContent:'space-between',
    marginTop: 30,
    height:200,
    width:'80%',
    backgroundColor:'white',   
    alignSelf:'center' 
  },
  inputBox: {
    borderRadius:12,
    height: 60,
    width: '90%',    
    borderWidth:1,
    borderColor:'white',
    alignItems:'center',
    paddingLeft: 8,
    paddingRight: 8,
  },
  contactTitle: {
    fontFamily: 'Cochin',
    fontSize: 20,
    fontWeight: 'bold',
    textAlign: 'center',
    paddingTop: 30,
  },
  contactListHead: {
    fontFamily: 'Cochin',
    fontSize: 20,
    fontWeight: 'bold',
    paddingTop: 30,
    marginLeft:20,
  },
});

export default Home;
