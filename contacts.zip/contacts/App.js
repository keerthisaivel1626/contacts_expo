import React from 'react';
import RootStack from './app/navigation/RootStack';
import {NavigationContainer} from '@react-navigation/native';

import { Provider } from 'react-redux';
import { PersistGate } from 'redux-persist/integration/react';
import configureStore from './app/store';

const { store, persistor } = configureStore();
const  App=()=> {
  return (
    <NavigationContainer>
      <RootStack />
    </NavigationContainer>
  );
}

export default () => {
  return (
    <Provider store={store}>
      <PersistGate loading={null} persistor={persistor}>
        <App />
      </PersistGate>
    </Provider>
  );
};
